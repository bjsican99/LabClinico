CREATE DATABASE  IF NOT EXISTS `labclinico` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `labclinico`;
-- MySQL dump 10.13  Distrib 8.0.21, for Win64 (x86_64)
--
-- Host: localhost    Database: labclinico
-- ------------------------------------------------------
-- Server version	8.0.21

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tbl_alergia`
--

DROP TABLE IF EXISTS `tbl_alergia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_alergia` (
  `pk_id_alergia` int NOT NULL AUTO_INCREMENT,
  `fk_idpaciente_alergia` int DEFAULT NULL,
  `descripcion_alergia` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`pk_id_alergia`),
  KEY `fk_aler_paci` (`fk_idpaciente_alergia`),
  CONSTRAINT `fk_aler_paci` FOREIGN KEY (`fk_idpaciente_alergia`) REFERENCES `tbl_paciente` (`pk_id_paciente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_alergia`
--

LOCK TABLES `tbl_alergia` WRITE;
/*!40000 ALTER TABLE `tbl_alergia` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_alergia` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_bitacora`
--

DROP TABLE IF EXISTS `tbl_bitacora`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_bitacora` (
  `pk_id_bitacora` int NOT NULL AUTO_INCREMENT,
  `fk_iduser_bitacora` int DEFAULT NULL,
  `fk_idtipoevent_bitacora` int DEFAULT NULL,
  `horaingreso_bitacora` varchar(50) DEFAULT NULL,
  `direchost_bitacora` varchar(20) DEFAULT NULL,
  `detalla_bitacora` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`pk_id_bitacora`),
  KEY `fk_bita_user` (`fk_iduser_bitacora`),
  KEY `fk_bita_tevnt` (`fk_idtipoevent_bitacora`),
  CONSTRAINT `fk_bita_tevnt` FOREIGN KEY (`fk_idtipoevent_bitacora`) REFERENCES `tbl_tipoevento` (`pk_id_tipoevento`),
  CONSTRAINT `fk_bita_user` FOREIGN KEY (`fk_iduser_bitacora`) REFERENCES `tbl_login` (`pk_id_login`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_bitacora`
--

LOCK TABLES `tbl_bitacora` WRITE;
/*!40000 ALTER TABLE `tbl_bitacora` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_bitacora` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_detallefactura`
--

DROP TABLE IF EXISTS `tbl_detallefactura`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_detallefactura` (
  `pk_id_detallefactura` int NOT NULL AUTO_INCREMENT,
  `fk_idencabezado_detallefactura` int DEFAULT NULL,
  `fk_idexamen_detallefactura` int DEFAULT NULL,
  `subtotal_detallefactura` double DEFAULT NULL,
  PRIMARY KEY (`pk_id_detallefactura`),
  KEY `fk_dfac_efac` (`fk_idencabezado_detallefactura`),
  KEY `fk_exam_dfac` (`fk_idexamen_detallefactura`),
  CONSTRAINT `fk_dfac_efac` FOREIGN KEY (`fk_idencabezado_detallefactura`) REFERENCES `tbl_encabezadofactura` (`pk_id_encabezadofactura`),
  CONSTRAINT `fk_exam_dfac` FOREIGN KEY (`fk_idexamen_detallefactura`) REFERENCES `tbl_examen` (`pk_id_examen`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_detallefactura`
--

LOCK TABLES `tbl_detallefactura` WRITE;
/*!40000 ALTER TABLE `tbl_detallefactura` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_detallefactura` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_doctor`
--

DROP TABLE IF EXISTS `tbl_doctor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_doctor` (
  `pk_id_doctor` int NOT NULL AUTO_INCREMENT,
  `nombre_doctor` varchar(20) DEFAULT NULL,
  `apellido_doctor` varchar(20) DEFAULT NULL,
  `dpi_doctor` int DEFAULT NULL,
  `direccion_doctor` varchar(50) DEFAULT NULL,
  `nit_doctor` int DEFAULT NULL,
  `fechanacimiento_doctor` date DEFAULT NULL,
  `fechaingreso_doctor` date DEFAULT NULL,
  `telefono_doctor` int DEFAULT NULL,
  `correo_doctor` varchar(50) DEFAULT NULL,
  `genero_doctor` int DEFAULT NULL,
  `fk_idestadocivil_doctor` int DEFAULT NULL,
  `estado_doctor` int DEFAULT NULL,
  PRIMARY KEY (`pk_id_doctor`),
  KEY `fk_doc_ecivil` (`fk_idestadocivil_doctor`),
  CONSTRAINT `fk_doc_ecivil` FOREIGN KEY (`fk_idestadocivil_doctor`) REFERENCES `tbl_estadocivil` (`pk_id_estadocivil`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_doctor`
--

LOCK TABLES `tbl_doctor` WRITE;
/*!40000 ALTER TABLE `tbl_doctor` DISABLE KEYS */;
INSERT INTO `tbl_doctor` VALUES (1,'Billy ','Sican',300694437,'7ma Avenida Zona 7',1234567,'1999-03-02','2020-08-15',54689270,'bjsican@gmail.com',1,2,1);
/*!40000 ALTER TABLE `tbl_doctor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_empleado`
--

DROP TABLE IF EXISTS `tbl_empleado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_empleado` (
  `pk_id_empleado` int NOT NULL AUTO_INCREMENT,
  `nombre_empleado` varchar(20) DEFAULT NULL,
  `apellido_empleado` varchar(20) DEFAULT NULL,
  `dpi_empleado` int DEFAULT NULL,
  `direccion_empleado` varchar(50) DEFAULT NULL,
  `nit_empleado` int DEFAULT NULL,
  `fechanacimiento_empleado` date DEFAULT NULL,
  `fechaingreso_empleado` date DEFAULT NULL,
  `telefono_empleado` int DEFAULT NULL,
  `correo_empleado` varchar(50) DEFAULT NULL,
  `genero_empleado` int DEFAULT NULL,
  `fk_idestadocivil_empleado` int DEFAULT NULL,
  `estado_empleado` int DEFAULT NULL,
  PRIMARY KEY (`pk_id_empleado`),
  KEY `fk_emp_ecivil` (`fk_idestadocivil_empleado`),
  CONSTRAINT `fk_emp_ecivil` FOREIGN KEY (`fk_idestadocivil_empleado`) REFERENCES `tbl_estadocivil` (`pk_id_estadocivil`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_empleado`
--

LOCK TABLES `tbl_empleado` WRITE;
/*!40000 ALTER TABLE `tbl_empleado` DISABLE KEYS */;
INSERT INTO `tbl_empleado` VALUES (1,'Billy','Sican',300694437,'7ma Avenida Zona 7',1234567,'1999-03-02','2020-08-15',54689270,'bjsican@gmail.com',1,2,1),(2,'Julio','Morataya',300694475,'8va Calle Zona 7',1234567,'1998-07-25','2020-08-15',69874512,'jmorataya@gmail.com',1,1,1),(3,'Brian','Santizo',300765925,'9na Calle Zona 18',2356478,'1998-06-25','2020-08-15',23568945,'bsantizo@gmail.com',1,2,1),(4,'Bryan ','Mazariegos',300789562,'5Av zona 18 ',2345789,'1998-07-26','2000-08-15',56892321,'bmazariegos@gmail.com',1,2,0),(5,'Jeshua ','Matias',300694523,'7ma Calle Zona 7',5468925,'1999-03-02','2020-08-15',54689250,'bjsicanm2@gmail.com',1,2,1);
/*!40000 ALTER TABLE `tbl_empleado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_encabezadofactura`
--

DROP TABLE IF EXISTS `tbl_encabezadofactura`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_encabezadofactura` (
  `pk_id_encabezadofactura` int NOT NULL AUTO_INCREMENT,
  `numserie_encabezadofactura` varchar(30) DEFAULT NULL,
  `numfactura_encabezadofactura` varchar(50) DEFAULT NULL,
  `nombre_encabezadofactura` varchar(30) DEFAULT NULL,
  `apellido_encabezadofactura` varchar(30) DEFAULT NULL,
  `nit_encabezadofactura` int DEFAULT NULL,
  `fechaorden_encabezadofactura` datetime DEFAULT NULL,
  `total_encabezadofactura` double DEFAULT NULL,
  `fk_idtipopago_encabezadofactura` int DEFAULT NULL,
  PRIMARY KEY (`pk_id_encabezadofactura`),
  KEY `fk_efac_tpago` (`fk_idtipopago_encabezadofactura`),
  CONSTRAINT `fk_efac_tpago` FOREIGN KEY (`fk_idtipopago_encabezadofactura`) REFERENCES `tbl_pago` (`pk_id_pago`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_encabezadofactura`
--

LOCK TABLES `tbl_encabezadofactura` WRITE;
/*!40000 ALTER TABLE `tbl_encabezadofactura` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_encabezadofactura` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_estadocivil`
--

DROP TABLE IF EXISTS `tbl_estadocivil`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_estadocivil` (
  `pk_id_estadocivil` int NOT NULL AUTO_INCREMENT,
  `tipo_estadocivil` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`pk_id_estadocivil`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_estadocivil`
--

LOCK TABLES `tbl_estadocivil` WRITE;
/*!40000 ALTER TABLE `tbl_estadocivil` DISABLE KEYS */;
INSERT INTO `tbl_estadocivil` VALUES (1,'Casado'),(2,'Soltero'),(3,'Divorciado'),(4,'Viudo ');
/*!40000 ALTER TABLE `tbl_estadocivil` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_examen`
--

DROP TABLE IF EXISTS `tbl_examen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_examen` (
  `pk_id_examen` int NOT NULL AUTO_INCREMENT,
  `nombre_examen` varchar(30) DEFAULT NULL,
  `precio_examen` double DEFAULT NULL,
  `fk_idtipoexam_examen` int DEFAULT NULL,
  `fk_idlaboratorio_examen` int DEFAULT NULL,
  `estado_laboratorio` int DEFAULT NULL,
  PRIMARY KEY (`pk_id_examen`),
  KEY `fk_exam_texam` (`fk_idtipoexam_examen`),
  KEY `fk_exam_lab` (`fk_idlaboratorio_examen`),
  CONSTRAINT `fk_exam_lab` FOREIGN KEY (`fk_idlaboratorio_examen`) REFERENCES `tbl_laboratorio` (`pk_id_laboratorio`),
  CONSTRAINT `fk_exam_texam` FOREIGN KEY (`fk_idtipoexam_examen`) REFERENCES `tbl_tipoexamen` (`pk_id_tipoexamen`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_examen`
--

LOCK TABLES `tbl_examen` WRITE;
/*!40000 ALTER TABLE `tbl_examen` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_examen` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_laboratorio`
--

DROP TABLE IF EXISTS `tbl_laboratorio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_laboratorio` (
  `pk_id_laboratorio` int NOT NULL AUTO_INCREMENT,
  `nombre_laboratorio` varchar(30) DEFAULT NULL,
  `direccion_laboratorio` varchar(30) DEFAULT NULL,
  `telefono_laboratorio` varchar(15) DEFAULT NULL,
  `email_laboratorio` varchar(50) DEFAULT NULL,
  `estado_laboratorio` int DEFAULT NULL,
  PRIMARY KEY (`pk_id_laboratorio`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_laboratorio`
--

LOCK TABLES `tbl_laboratorio` WRITE;
/*!40000 ALTER TABLE `tbl_laboratorio` DISABLE KEYS */;
INSERT INTO `tbl_laboratorio` VALUES (1,'San Juan de Dios','8va Calle Zona 1','5689235','sjdios@gmail.com',1);
/*!40000 ALTER TABLE `tbl_laboratorio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_login`
--

DROP TABLE IF EXISTS `tbl_login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_login` (
  `pk_id_login` int NOT NULL AUTO_INCREMENT,
  `usuario_login` varchar(45) DEFAULT NULL,
  `contraseña_login` varchar(45) DEFAULT NULL,
  `estado_login` int DEFAULT NULL,
  `fk_idempleado_login` int DEFAULT NULL,
  `fk_idpermiso_login` int DEFAULT NULL,
  PRIMARY KEY (`pk_id_login`),
  KEY `fk_perm_user` (`fk_idempleado_login`),
  CONSTRAINT `fk_per_user` FOREIGN KEY (`fk_idempleado_login`) REFERENCES `tbl_empleado` (`pk_id_empleado`),
  CONSTRAINT `fk_perm_user` FOREIGN KEY (`fk_idempleado_login`) REFERENCES `tbl_permiso` (`pk_id_permiso`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_login`
--

LOCK TABLES `tbl_login` WRITE;
/*!40000 ALTER TABLE `tbl_login` DISABLE KEYS */;
INSERT INTO `tbl_login` VALUES (1,'bjsican','bjsican',1,1,1),(2,'jmorataya','morataya',1,2,2);
/*!40000 ALTER TABLE `tbl_login` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_muestra`
--

DROP TABLE IF EXISTS `tbl_muestra`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_muestra` (
  `pk_id_muestra` int NOT NULL AUTO_INCREMENT,
  `fk_idpaciente_muestra` int DEFAULT NULL,
  `fechaobtencion_muestra` date DEFAULT NULL,
  `descripcion_muestra` varchar(50) DEFAULT NULL,
  `estado_muestra` int DEFAULT NULL,
  PRIMARY KEY (`pk_id_muestra`),
  KEY `fk_mues_paci` (`fk_idpaciente_muestra`),
  CONSTRAINT `fk_mues_paci` FOREIGN KEY (`fk_idpaciente_muestra`) REFERENCES `tbl_paciente` (`pk_id_paciente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_muestra`
--

LOCK TABLES `tbl_muestra` WRITE;
/*!40000 ALTER TABLE `tbl_muestra` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_muestra` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_paciente`
--

DROP TABLE IF EXISTS `tbl_paciente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_paciente` (
  `pk_id_paciente` int NOT NULL AUTO_INCREMENT,
  `nombre_paciente` varchar(20) DEFAULT NULL,
  `apellido_paciente` varchar(20) DEFAULT NULL,
  `dpi_paciente` int DEFAULT NULL,
  `direccion_paciente` varchar(50) DEFAULT NULL,
  `nit_paciente` int DEFAULT NULL,
  `fechanacimiento_paciente` date DEFAULT NULL,
  `fechaingreso_paciente` date DEFAULT NULL,
  `telefono_paciente` int DEFAULT NULL,
  `correo_paciente` varchar(50) DEFAULT NULL,
  `genero_paciente` int DEFAULT NULL,
  `fk_idestadocivil_paciente` int DEFAULT NULL,
  `estado_paciente` int DEFAULT NULL,
  PRIMARY KEY (`pk_id_paciente`),
  KEY `fk_paci_ecivil` (`fk_idestadocivil_paciente`),
  CONSTRAINT `fk_paci_ecivil` FOREIGN KEY (`fk_idestadocivil_paciente`) REFERENCES `tbl_estadocivil` (`pk_id_estadocivil`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_paciente`
--

LOCK TABLES `tbl_paciente` WRITE;
/*!40000 ALTER TABLE `tbl_paciente` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_paciente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_pago`
--

DROP TABLE IF EXISTS `tbl_pago`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_pago` (
  `pk_id_pago` int NOT NULL AUTO_INCREMENT,
  `tipo_pago` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`pk_id_pago`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_pago`
--

LOCK TABLES `tbl_pago` WRITE;
/*!40000 ALTER TABLE `tbl_pago` DISABLE KEYS */;
INSERT INTO `tbl_pago` VALUES (1,'Efectivo'),(2,'Cheque'),(3,'Deposito'),(4,'Seguro');
/*!40000 ALTER TABLE `tbl_pago` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_permiso`
--

DROP TABLE IF EXISTS `tbl_permiso`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_permiso` (
  `pk_id_permiso` int NOT NULL AUTO_INCREMENT,
  `tipo_permiso` varchar(25) DEFAULT NULL,
  `descripcon_permiso` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`pk_id_permiso`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_permiso`
--

LOCK TABLES `tbl_permiso` WRITE;
/*!40000 ALTER TABLE `tbl_permiso` DISABLE KEYS */;
INSERT INTO `tbl_permiso` VALUES (1,'Admin','Administrador'),(2,'User','Usuario');
/*!40000 ALTER TABLE `tbl_permiso` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_procesomuestra`
--

DROP TABLE IF EXISTS `tbl_procesomuestra`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_procesomuestra` (
  `pk_id_procesomuestra` int NOT NULL AUTO_INCREMENT,
  `fk_idmuestra_procesomuestra` int DEFAULT NULL,
  `fk_idexman_procesomuestra` int DEFAULT NULL,
  `fk_iddoctor_procesomuestra` int DEFAULT NULL,
  `fecha_procesomuestra` date DEFAULT NULL,
  `observaciones_procesomuestra` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`pk_id_procesomuestra`),
  KEY `fk_proc_mues` (`fk_idmuestra_procesomuestra`),
  KEY `fk_proc_exam` (`fk_idexman_procesomuestra`),
  KEY `fk_proc_doc` (`fk_iddoctor_procesomuestra`),
  CONSTRAINT `fk_proc_doc` FOREIGN KEY (`fk_iddoctor_procesomuestra`) REFERENCES `tbl_doctor` (`pk_id_doctor`),
  CONSTRAINT `fk_proc_exam` FOREIGN KEY (`fk_idexman_procesomuestra`) REFERENCES `tbl_examen` (`pk_id_examen`),
  CONSTRAINT `fk_proc_mues` FOREIGN KEY (`fk_idmuestra_procesomuestra`) REFERENCES `tbl_muestra` (`pk_id_muestra`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_procesomuestra`
--

LOCK TABLES `tbl_procesomuestra` WRITE;
/*!40000 ALTER TABLE `tbl_procesomuestra` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_procesomuestra` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_referencia`
--

DROP TABLE IF EXISTS `tbl_referencia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_referencia` (
  `pk_id_referencia` int NOT NULL AUTO_INCREMENT,
  `fk_idpaciente_referencia` int DEFAULT NULL,
  `fk_iddoctor_referencia` int DEFAULT NULL,
  PRIMARY KEY (`pk_id_referencia`),
  KEY `fk_ref_paci` (`fk_idpaciente_referencia`),
  KEY `fk_ref_doct` (`fk_iddoctor_referencia`),
  CONSTRAINT `fk_ref_doct` FOREIGN KEY (`fk_iddoctor_referencia`) REFERENCES `tbl_doctor` (`pk_id_doctor`),
  CONSTRAINT `fk_ref_paci` FOREIGN KEY (`fk_idpaciente_referencia`) REFERENCES `tbl_paciente` (`pk_id_paciente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_referencia`
--

LOCK TABLES `tbl_referencia` WRITE;
/*!40000 ALTER TABLE `tbl_referencia` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_referencia` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_tipoevento`
--

DROP TABLE IF EXISTS `tbl_tipoevento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_tipoevento` (
  `pk_id_tipoevento` int NOT NULL AUTO_INCREMENT,
  `descripcione_tipoevento` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`pk_id_tipoevento`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_tipoevento`
--

LOCK TABLES `tbl_tipoevento` WRITE;
/*!40000 ALTER TABLE `tbl_tipoevento` DISABLE KEYS */;
INSERT INTO `tbl_tipoevento` VALUES (1,'Login'),(2,'Click Paciente'),(3,'Click Reportes'),(4,'Click Facturacion'),(5,'Click Personal'),(6,'Click Examenes'),(7,'Click Etiqueta'),(8,'Click Ingre Doctor'),(9,'Click Salir'),(10,'Nuevo Paciente'),(11,'Guardar Paciente'),(12,'Modificar Paciente'),(13,'Eliminar Paciente'),(14,'Grabar'),(15,'Error Grabar'),(16,'Modificar'),(17,'Eliminar'),(18,'Error Modificar'),(19,'Eliminar'),(20,'Error Eliminar'),(21,'Consulta'),(22,'Error Consulta'),(23,'Etiqueta'),(24,'Buscar'),(25,'Imprimir');
/*!40000 ALTER TABLE `tbl_tipoevento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_tipoexamen`
--

DROP TABLE IF EXISTS `tbl_tipoexamen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_tipoexamen` (
  `pk_id_tipoexamen` int NOT NULL AUTO_INCREMENT,
  `nom_tipoexamen` varchar(35) DEFAULT NULL,
  `descripcion_tipoexamen` varchar(35) DEFAULT NULL,
  `estado_laboratorio` int DEFAULT NULL,
  PRIMARY KEY (`pk_id_tipoexamen`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_tipoexamen`
--

LOCK TABLES `tbl_tipoexamen` WRITE;
/*!40000 ALTER TABLE `tbl_tipoexamen` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_tipoexamen` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'labclinico'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-08-15 17:54:15
