CREATE DATABASE  IF NOT EXISTS `labclinico` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `labclinico`;
-- MySQL dump 10.13  Distrib 8.0.21, for Win64 (x86_64)
--
-- Host: localhost    Database: labclinico
-- ------------------------------------------------------
-- Server version	8.0.21

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tbl_empleado`
--

DROP TABLE IF EXISTS `tbl_empleado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_empleado` (
  `pk_id_empleado` int NOT NULL AUTO_INCREMENT,
  `nombre_empleado` varchar(20) DEFAULT NULL,
  `apellido_empleado` varchar(20) DEFAULT NULL,
  `dpi_empleado` int DEFAULT NULL,
  `direccion_empleado` varchar(50) DEFAULT NULL,
  `nit_empleado` int DEFAULT NULL,
  `fechanacimiento_empleado` date DEFAULT NULL,
  `fechaingreso_empleado` date DEFAULT NULL,
  `telefono_empleado` int DEFAULT NULL,
  `correo_empleado` varchar(50) DEFAULT NULL,
  `genero_empleado` int DEFAULT NULL,
  `fk_idestadocivil_empleado` int DEFAULT NULL,
  `estado_empleado` int DEFAULT NULL,
  PRIMARY KEY (`pk_id_empleado`),
  KEY `fk_emp_ecivil` (`fk_idestadocivil_empleado`),
  CONSTRAINT `fk_emp_ecivil` FOREIGN KEY (`fk_idestadocivil_empleado`) REFERENCES `tbl_estadocivil` (`pk_id_estadocivil`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_empleado`
--

LOCK TABLES `tbl_empleado` WRITE;
/*!40000 ALTER TABLE `tbl_empleado` DISABLE KEYS */;
INSERT INTO `tbl_empleado` VALUES (1,'Bryan','Mazariegos',1222344,'kwejflksdjfkjsdkfheow',3241982,'1998-11-13','2020-08-18',12345678,'bryanesturd3@gmail.com',1,1,1),(2,'Billy','Sican',300694437,'7ma Avenida Zona 7',1234567,'1999-03-02','2020-08-15',54689270,'bjsican@gmail.com',1,2,1),(3,'Julio','Morataya',300694475,'8va Calle Zona 7',1234567,'1998-07-25','2020-08-15',69874512,'jmorataya@gmail.com',1,3,1),(4,'Brian','Santizo',300765925,'9na Calle Zona 18',2356478,'1998-06-25','2020-08-15',23568945,'bsantizo@gmail.com',1,4,1),(5,'Bryan ','Mazariegos',300789562,'5Av zona 18 ',2345789,'1998-07-26','2000-08-15',56892321,'bmazariegos@gmail.com',1,1,1),(6,'Jeshua ','Matias',300694523,'7ma Calle Zona 7',5468925,'1999-03-02','2020-08-15',54689250,'bjsicanm2@gmail.com',1,1,1),(7,'Bryanmm','Mazariegosmm',12231,'wdsad',23,'1998-07-26','2000-08-18',12321332,'dshgd',1,1,0),(8,'prueba','mprue',1123321,'123sfd',234565,'2000-02-11','2020-08-18',23454355,'brye3@gmail.com',1,3,1);
/*!40000 ALTER TABLE `tbl_empleado` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-08-20 18:51:16
